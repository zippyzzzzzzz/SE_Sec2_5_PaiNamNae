import{ai as e,C as t}from"./Dlg5KKmK.js";import{u as a}from"./B5IKhgPp.js";const u=e(o=>{if(!a("token").value&&o.path!=="/login")return t("/login")});export{u as default};
