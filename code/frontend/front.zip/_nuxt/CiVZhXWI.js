import{aj as e,D as t}from"./BCfR4clq.js";import{u as a}from"./Mj95yajF.js";const u=e(o=>{if(!a("token").value&&o.path!=="/login")return t("/login")});export{u as default};
