import{ai as e,D as t}from"./CtsJ6gOl.js";import{u as a}from"./BgnfmyNg.js";const u=e(o=>{if(!a("token").value&&o.path!=="/login")return t("/login")});export{u as default};
